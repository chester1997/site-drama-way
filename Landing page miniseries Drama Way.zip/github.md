repo: chester1997/site-drama-way
branch: main

## Last sync
date: 2026-08-23T20:55:00Z

### Updated in this project
- Repositório associado ao projeto (ainda vazio no GitHub — nada importado).
- Landing page da Drama Way construída neste projeto, pronta para ser publicada no repo.

## Screen map
| Screen | Repo files |
| --- | --- |
| Drama Way Landing.dc.html | — (ainda não versionado no repo) |
